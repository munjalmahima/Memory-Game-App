package com.example.myapplication;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Arrays;
import java.util.Collections;

public class MainActivity extends AppCompatActivity {

    TextView t;
    ImageView q1,q2,q3,q4,q5,q6,q7,q8,q9,q10,q11,q12;
    Integer[] cardsArray={101,102,103,104,105,106,201,202,203,204,205,206};
    int im101,im102,im103,im104,im105,im106,im201,im202,im203,im204,im205,im206;
    int firstCard,secondCard,clickedFirst,clickedSecond;
    int cardNumber=1,playerPoints=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        t = (TextView) findViewById(R.id.textView);
        q1 = (ImageView) findViewById(R.id.q1);
        q2 = (ImageView) findViewById(R.id.q2);
        q3 = (ImageView) findViewById(R.id.q3);
        q4 = (ImageView) findViewById(R.id.q4);
        q5 = (ImageView) findViewById(R.id.q5);
        q6 = (ImageView) findViewById(R.id.q6);
        q7 = (ImageView) findViewById(R.id.q7);
        q8 = (ImageView) findViewById(R.id.q8);
        q9 = (ImageView) findViewById(R.id.q9);
        q10 = (ImageView) findViewById(R.id.q10);
        q11 = (ImageView) findViewById(R.id.q11);
        q12 = (ImageView) findViewById(R.id.q12);

        q1.setTag("0");
        q2.setTag("1");
        q3.setTag("2");
        q4.setTag("3");
        q5.setTag("4");
        q6.setTag("5");
        q7.setTag("6");
        q8.setTag("7");
        q9.setTag("8");
        q10.setTag("9");
        q11.setTag("10");
        q12.setTag("11");

        frontCardResources();
        Collections.shuffle(Arrays.asList(cardsArray));
        t.setTextColor(Color.BLUE);

        q1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                int theCard = Integer.parseInt((String) v.getTag());
                doStuff(q1, theCard);
            }
        });

        q2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                int theCard = Integer.parseInt((String) v.getTag());
                doStuff(q2, theCard);
            }
        });

        q3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                int theCard = Integer.parseInt((String) v.getTag());
                doStuff(q3, theCard);
            }
        });

        q4.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                int theCard = Integer.parseInt((String) v.getTag());
                doStuff(q4, theCard);
            }
        });

        q5.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                int theCard = Integer.parseInt((String) v.getTag());
                doStuff(q5, theCard);
            }
        });

        q6.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                int theCard = Integer.parseInt((String) v.getTag());
                doStuff(q6, theCard);
            }
        });

        q7.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                int theCard = Integer.parseInt((String) v.getTag());
                doStuff(q7, theCard);
            }
        });

        q8.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                int theCard = Integer.parseInt((String) v.getTag());
                doStuff(q8, theCard);
            }
        });

        q9.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                int theCard = Integer.parseInt((String) v.getTag());
                doStuff(q9, theCard);
            }
        });
        q10.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                int theCard = Integer.parseInt((String) v.getTag());
                doStuff(q10, theCard);
            }
        });
        q11.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                int theCard = Integer.parseInt((String) v.getTag());
                doStuff(q11, theCard);
            }
        });
        q12.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                int theCard = Integer.parseInt((String) v.getTag());
                doStuff(q12, theCard);
            }
        });

    }
    private void doStuff(ImageView iv,int card)
    {
        if(cardsArray[card]==101)
        {
            iv.setImageResource(im101);
        }
        else if(cardsArray[card]==102)
        {
            iv.setImageResource(im102);
        }
        else if(cardsArray[card]==103)
        {
            iv.setImageResource(im103);
        }
        else if(cardsArray[card]==104)
        {
            iv.setImageResource(im104);
        }
        else if(cardsArray[card]==105)
        {
            iv.setImageResource(im105);
        }
        else if(cardsArray[card]==106)
        {
            iv.setImageResource(im106);
        }
        else if(cardsArray[card]==107)
        {
            iv.setImageResource(im201);
        }
        else if(cardsArray[card]==201)
        {
            iv.setImageResource(im202);
        }
        else if(cardsArray[card]==202)
        {
            iv.setImageResource(im103);
        }
        else if(cardsArray[card]==203)
        {
            iv.setImageResource(im203);
        }
        else if(cardsArray[card]==204)
        {
            iv.setImageResource(im204);
        }
        else if(cardsArray[card]==205)
        {
            iv.setImageResource(im205);
        }
        else if(cardsArray[card]==206)
        {
            iv.setImageResource(im206);
        }

        if(cardNumber==1)
        {
            firstCard=cardsArray[card];
            if(firstCard>200)
            {
                firstCard=firstCard-100;
            }
            cardNumber=2;
            clickedFirst=card;
            iv.setEnabled(false);
        }
        else if(cardNumber==2)
        {
            secondCard=cardsArray[card];
            if(secondCard>200)
            {
                secondCard=secondCard-100;
            }
            cardNumber=1;
            clickedSecond=card;

            q1.setEnabled(false);
            q2.setEnabled(false);
            q3.setEnabled(false);
            q4.setEnabled(false);
            q5.setEnabled(false);
            q6.setEnabled(false);
            q7.setEnabled(false);
            q8.setEnabled(false);
            q9.setEnabled(false);
            q10.setEnabled(false);
            q11.setEnabled(false);
            q12.setEnabled(false);

            Handler handler=new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    calculate();
                }
            },1000);

        }
    }
    private void calculate()
    {
        if(firstCard==secondCard)
        {
            if(clickedFirst==0)
            {
                q1.setVisibility(View.INVISIBLE);
            }
            else if(clickedFirst==1)
            {
                q2.setVisibility(View.INVISIBLE);
            }
            else if(clickedFirst==2)
            {
                q3.setVisibility(View.INVISIBLE);
            }
            else if(clickedFirst==3)
            {
                q4.setVisibility(View.INVISIBLE);
            }
            else if(clickedFirst==4)
            {
                q5.setVisibility(View.INVISIBLE);
            }
            else if(clickedFirst==5)
            {
                q6.setVisibility(View.INVISIBLE);
            }
            else if(clickedFirst==6)
            {
                q7.setVisibility(View.INVISIBLE);
            }
            else if(clickedFirst==7)
            {
                q8.setVisibility(View.INVISIBLE);
            }
            else if(clickedFirst==8)
            {
                q9.setVisibility(View.INVISIBLE);
            }
            else if(clickedFirst==9)
            {
                q10.setVisibility(View.INVISIBLE);
            }
            else if(clickedFirst==10)
            {
                q11.setVisibility(View.INVISIBLE);
            }
            else if(clickedFirst==11)
            {
                q12.setVisibility(View.INVISIBLE);
            }

            if(clickedSecond==0)
            {
                q1.setVisibility(View.INVISIBLE);
            }
            else if(clickedSecond==1)
            {
                q2.setVisibility(View.INVISIBLE);
            }
            else if(clickedSecond==2)
            {
                q3.setVisibility(View.INVISIBLE);
            }
            else if(clickedSecond==3)
            {
                q4.setVisibility(View.INVISIBLE);
            }
            else if(clickedSecond==4)
            {
                q5.setVisibility(View.INVISIBLE);
            }
            else if(clickedSecond==5)
            {
                q6.setVisibility(View.INVISIBLE);
            }
            else if(clickedSecond==6)
            {
                q7.setVisibility(View.INVISIBLE);
            }
            else if(clickedSecond==7)
            {
                q8.setVisibility(View.INVISIBLE);
            }
            else if(clickedSecond==8)
            {
                q9.setVisibility(View.INVISIBLE);
            }
            else if(clickedSecond==9)
            {
                q10.setVisibility(View.INVISIBLE);
            }
            else if(clickedSecond==10)
            {
                q11.setVisibility(View.INVISIBLE);
            }
            else if(clickedSecond==11)
            {
                q12.setVisibility(View.INVISIBLE);
            }
                playerPoints++;
                t.setText("Score : "+playerPoints);
            }
        else
        {
            q1.setImageResource(R.drawable.question);
            q2.setImageResource(R.drawable.question);
            q3.setImageResource(R.drawable.question);
            q4.setImageResource(R.drawable.question);
            q5.setImageResource(R.drawable.question);
            q6.setImageResource(R.drawable.question);
            q7.setImageResource(R.drawable.question);
            q8.setImageResource(R.drawable.question);
            q9.setImageResource(R.drawable.question);
            q10.setImageResource(R.drawable.question);
            q11.setImageResource(R.drawable.question);
            q12.setImageResource(R.drawable.question);
        }
        q1.setEnabled(true);
        q2.setEnabled(true);
        q3.setEnabled(true);
        q4.setEnabled(true);
        q5.setEnabled(true);
        q6.setEnabled(true);
        q7.setEnabled(true);
        q8.setEnabled(true);
        q9.setEnabled(true);
        q10.setEnabled(true);
        q11.setEnabled(true);
        q12.setEnabled(true);

        checkEnd();
    }

    private void checkEnd()
    {
        if(q1.getVisibility()==View.INVISIBLE &&
                q1.getVisibility()==View.INVISIBLE &&
                q2.getVisibility()==View.INVISIBLE &&
                q3.getVisibility()==View.INVISIBLE &&
                q4.getVisibility()==View.INVISIBLE &&
                q5.getVisibility()==View.INVISIBLE &&
                q6.getVisibility()==View.INVISIBLE &&
                q7.getVisibility()==View.INVISIBLE &&
                q8.getVisibility()==View.INVISIBLE &&
                q9.getVisibility()==View.INVISIBLE &&
                q10.getVisibility()==View.INVISIBLE &&
                q11.getVisibility()==View.INVISIBLE &&
                q12.getVisibility()==View.INVISIBLE )
        {
            AlertDialog.Builder alertDialogBuilder;
            alertDialogBuilder = new AlertDialog.Builder(MainActivity.this);
            alertDialogBuilder.setMessage("GAME OVER \nScore: "+ playerPoints)
            .setCancelable(false)
        .setPositiveButton("NEW",new DialogInterface.OnClickListener(){
                public void onClick(DialogInterface dialogInterface,int i)
                {
                   Intent intent=new Intent(getApplication(),MainActivity.class);
                   startActivity(intent);
                   finish();
                }
        }).setNegativeButton("EXIT",new DialogInterface.OnClickListener(){
                    public void onClick(DialogInterface dialogInterface,int i)
                    {
                        finish();
                    }
                });
            AlertDialog alertDialog=alertDialogBuilder.create();
            alertDialog.show();
        }

    }


    private void frontCardResources()
    {
        im101=R.drawable.bird;
        im102=R.drawable.cat;
        im103=R.drawable.dog;
        im104=R.drawable.tree;
        im105=R.drawable.flower;
        im106=R.drawable.elephant;
        im201=R.drawable.bird1;
        im202=R.drawable.cat1;
        im203=R.drawable.dog1;
        im204=R.drawable.tree1;
        im205=R.drawable.flower1;
        im206=R.drawable.elephant1;
    }
}
